import scala.collection.mutable._
import scala.io.StdIn.readLine
import scala.math.pow
import scala.util.control.Breaks.break
object App {
 def main(args: Array[String]): Unit = {
  //Задание 3a выполнено из расчета, что годовой доход это оклад+питание+премия за вычетом подоходного налога
  println("Hello, Scala!")
  var myString = "Hello, Scala!"
  println(myString.reverse)
  println(myString.dropRight(1))
  println(myString.toLowerCase())
  println(myString.dropRight(1).concat(" and goodbye python!"))
//Задание 3b
  print("Введите годовой доход:")
  val s = readLine().toFloat
  print("Введите размер премии в процентах:")
  val sBonus = readLine().toFloat
  print("Введите размер компенсации на питание:")
  val mBonus = readLine().toFloat
  println("Ваш ежемесячный оклад составляет:",(s-s*sBonus/100-mBonus)/0.87/12)
  //Задание 3c
  val personnelSalary = List(100, 150, 200, 80, 120, 75)
  val salarySum = personnelSalary.sum
  val salaryCount = personnelSalary.length
  val salaryMean = personnelSalary.sum / personnelSalary.length
  println("Отклонение зарплаты от средней по отделу:")
  for (n <- personnelSalary) {
  val dev = n * 100 / salaryMean - 100
   print(dev + " ") //Отклонение от средней зарплаты
  }
  println()
  //Задание 3d
  var newSalary = personnelSalary.patch(2, List(130), 1)
  println(newSalary) //3-му сотруднику снижаем зарплату
  println("Максимальная зарплата", newSalary.max)
  println("Минимальная зарплата", newSalary.min)
  //Задание 3е
  newSalary = 350 :: newSalary
  newSalary = 90 :: newSalary
  println(newSalary.sorted)
  //Задание 3f
  val result = newSalary.sorted.indexWhere(x => {
   x >= 130
  })
  println(result)
  val Salary = newSalary.sorted.patch(result, List(130), 0)
  println(Salary)
  //Задание 3g
  for (n <- Salary) {
   if ((n > 130) && (n < 250))
    println(n, "middle")
  }
  //Задание 3h
  println("Зарплата после индексации на уровень инфляции:")
  var indexSalary = List[Int]()
  for (n <- Salary) {
   indexSalary = math.ceil(n * 1.07).toInt +:indexSalary
  }
  println(indexSalary.sorted)
  //Увеличим сотрудникам отдела категории "middle" зарплату на уровень рынка
  val avgSalaryByMarket = 178
  var middleSalary = List[Int]()
  for (n <- indexSalary) {
   if ((n > 120) && (n < 250)) {
    middleSalary = n +: middleSalary
   }
  }
  println(middleSalary)
  val avgMiddleSalary = middleSalary.sum / middleSalary.length
  println(avgMiddleSalary)
  val avgMiddleSalaryConv:Float= 1- avgMiddleSalary.toFloat/avgSalaryByMarket.toFloat
  println(avgMiddleSalaryConv)
  var finalSalary = List[Float]()
  for (n <- indexSalary) {
   if ((n > 120) && (n < 250)) {
    finalSalary=n*(1+avgMiddleSalaryConv)+:finalSalary
   }
    else { finalSalary=n+:finalSalary
   }
   }
  println(finalSalary.sorted)
  //Деанонимизация сотрудников
  val personSalary= Map(
   "Васильев Иван" ->107,
   "Соколов Петр" -> 193,
   "Орлов Евгений" -> 375,
   "Синицина Наталья" -> 168,
   "Кукушкина Ольга" -> 97,
   "Перепелкин Максим" -> 168,
   "Гусев Андрей" -> 155,
   "Уткина Марина" -> 81,
   "Воробъев Александр" -> 86
  )
  println(personSalary)
  //Вывод данных работников с наибольшей и наименьшей зарплатой
  var salaryMax=0
  var nameOfPersonSalaryMax=""
  for ((i, j)<-personSalary) {
   if (j>salaryMax) {
    salaryMax=j
    nameOfPersonSalaryMax=i
   }
  }
  println("Сотрудник с наибольшей зарплатой:" + nameOfPersonSalaryMax)
  var salaryMin = 0
  var nameOfPersonSalaryMin = ""
  for ((i, j) <- personSalary) {
   if (j < salaryMax) {
    salaryMin = j
    nameOfPersonSalaryMin = i
   }
  }
  println("Сотрудник с наименьшей зарплатой:" + nameOfPersonSalaryMin)
  var name=List[Any]()
  var salValue=List[Int]()
  for ((i, j) <- personSalary) {
   name = i+:name
   salValue = j+:salValue
   }
  //Задание 3m
   def changeSymbol(str: String): String = {
   str.replaceAll("ё", "").replaceAll("у", "").replaceAll("у", "").replaceAll("е", "").replaceAll("ы", "").replaceAll("а", "").replaceAll("о", "").replaceAll("э", "").replaceAll("я", "").replaceAll("и", "").replaceAll("о", "")
   }
  var finalNames=List[Any]()
  for (n <- name) {
   val names = changeSymbol(n.toString.replaceAll("\\s.*",  " ").toLowerCase().replaceAll("а",  "").reverse)
   finalNames=names+:finalNames
  }
  val finalResult = (finalNames zip salValue).toMap
  println(finalResult)

  //Задание 3n
  def salary(s: Float, b: Float, m: Float): Any = {
   (s - s * b / 100 - m) / 0.87 / 12
  }
  print ("Введите годовой доход:")
  val revenue = readLine().toFloat
  print("Введите размер премии в процентах:")
  val salaryBonus = readLine().toFloat
  print("Введите размер компенсации на питание:")
  val meal = readLine().toFloat
  val res= salary(revenue,salaryBonus,meal)
  println("Ваш ежемесячный оклад составляет:",res)
//Задание 3o
  def powOfTwo(n: Int):Double= {
    if (n==1) 2
    else 2*powOfTwo(n-1)
  }
  println(powOfTwo(10).toInt)

  def powOfTwoTail(n: Int): Double = {
   def loop(n: Int, agg: Int): Double = {
    if (n == 1) agg
    else agg*loop(n - 1,agg)
   }
   loop(n,agg=2)
  }
  println(powOfTwoTail(10).toInt)
 }
}
